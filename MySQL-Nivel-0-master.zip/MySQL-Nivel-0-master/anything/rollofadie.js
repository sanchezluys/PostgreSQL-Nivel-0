let rollofadie = (function(container, options){ 
  container.innerHTML =  Math.trunc( Math.random() * 6 ) + 1;
})
